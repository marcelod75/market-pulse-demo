﻿# Market Pulse – Demo (Local)

## Como rodar
1) Já está rodando agora em: http://127.0.0.1:8020/docs
2) Para parar: Stop-Process -Id  -Force

## Entregáveis
- entregaveis\openapi.json
- entregaveis\postman_collection.json
- entregaveis\architecture_diagram.mmd
- entregaveis\example_daily_briefing.md
- entregaveis\adf_pipeline_market_pulse.json
- entregaveis\adf_trigger_schedule.json
- entregaveis\azure-pipelines.yml
- entregaveis\dbx_etl_news.py
- entregaveis\cosmos_setup.bicep
