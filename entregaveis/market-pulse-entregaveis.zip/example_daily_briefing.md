﻿# Boletim Diário – Market Pulse (Exemplo)

**Top 3 tópicos**
1) Queda da taxa de juros — impacto positivo em varejo e construção.
2) Greve logística — risco de atrasos e custos de frete (negativo).
3) Expectativa de resultados trimestrais — volatilidade setorial.

**Sentimento predominante**: Misto (Positivo em juros, Negativo em logística, Neutro em resultados).

**Resumo executivo**
- Corte de juros melhora condições financeiras (consumo, crédito).
- Greve pode pressionar margens e prazos de entrega.
- Resultados próximos mantêm cautela dos investidores.
